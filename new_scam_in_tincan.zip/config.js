//globals: equal, responseText, statement, ok, deepEqual, QUnit, module, asyncTest, Util, start, golfStatements, console
/*jslint bitwise: true, browser: true, plusplus: true, maxerr: 50, indent: 4 */
function Config() {
	"use strict";
}
Config.endpoint = "https://shearwater.gq/data/xAPI/";
Config.authUser = "815147c814f95d1ba9a7f7cdfe54e46f9caea2d8";
Config.authPassword = "b7e9d80d804850b90229c9a7173da70ae123292f";
Config.actor = { "mbox": "new_scam@emailsd.com", "name": "Tommy"};